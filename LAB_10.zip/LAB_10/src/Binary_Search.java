import java.util.Scanner;

public class Binary_Search {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int size , item, mid = 0, beg=0, end,count=0,last_occ = 0;
        boolean found = false;
        System.out.println("Enter the length of array:");
        size = sc.nextInt();
        int[] array = new int[size];
        for (int i=0;i<size;i++){
            System.out.println("Enter the element "+i+" : ");
            array[i]= sc.nextInt();
        }
        System.out.println("Enter item to be searched");
        item = sc.nextInt();
        end =size-1;
        while (beg <= end){
            mid = (beg + end) /2;
            if (array[mid] == item){
                found = true;
                count++;
                if (count == 1){
                    System.out.println("First Occurrence at index "+ mid);
                }
                last_occ = mid;
                beg=mid + 1;
            }
            else if (array[mid] < item)
                beg=mid + 1;
            else if (array[mid] > item)
                end=mid - 1;
        }
        if (found == true){
            System.out.println("Number of time occurred: "+count);
            if (count > 1 )
            {
                System.out.println("Last Occurrence at index "+ last_occ);
            }
        }
        else {
            System.out.println("Item not found");
        }
    }
}
