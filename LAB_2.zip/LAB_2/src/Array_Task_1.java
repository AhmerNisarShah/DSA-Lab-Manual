import java.util.Scanner;

public class Array_Task_1 {
    public void sum_array(int[] num){
        int total = 0;
        for (int i=0; i<num.length;i++){
            total = total + num[i];
        }
        System.out.println("Sum of array is: "+total);
    }

    public void max_array(int[] num){
        int max_array = num[0];
        for(int i=0;i<num.length;i++){
            if(max_array<=num[i]){
                max_array = num[i];
            }
        }
        System.out.println("The maximum value in the array is: "+max_array);
    }

    public void avg_array(int[] num){
        int total=0;
        for (int i=0;i<num.length;i++){
            total = total + num[i];
        }
        double average = (total / num.length);
        System.out.println("The average of the array is: "+average);
    }

    public void min_array(int[] num){
        int min_array = num[0];
        for(int i=0;i<num.length;i++){
            if(min_array>=num[i]){
                min_array = num[i];
            }
        }
        System.out.println("The minimum value in the array is: "+min_array);
    }

    public void mul_array(int[] num){
        int total = 1;
        for (int i=0; i<num.length;i++){
            total = total * num[i];
        }
        System.out.println("Product of array is: "+total);
    }

    public void even_array(int[] num){
        System.out.println("Even numbers: ");
        for(int i=0;i<num.length;i++){
            if(num[i]%2==0){
                System.out.println(num[i]);
            }
        }
    }
    public void odd_array(int[] num){
        System.out.println("Odd numbers: ");
        for(int i=0;i<num.length;i++){
            if(num[i]%2!=0){
                System.out.println(num[i]);
            }
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the length of the array: ");
        int arr = sc.nextInt();
        int[] a = new int[arr];
        for (int i=0;i<arr;i++){
            System.out.println("Enter the element number "+i+": ");
            a[i]=sc.nextInt();
        }
        Array_Task_1 ar = new Array_Task_1();
        int z;
        do{
            System.out.println("Select Operation\n1)Sum\n2)Product\n3)Maximum\n4)Minimum\n5)Average\n6)Even\n7)Odd");
            int c = sc.nextInt();
            switch (c) {
                case 1:
                    ar.sum_array(a);
                    break;
                case 2:
                    ar.mul_array(a);
                    break;
                case 3:
                    ar.max_array(a);
                    break;
                case 4:
                    ar.min_array(a);
                    break;
                case 5:
                    ar.avg_array(a);
                    break;
                case 6:
                    ar.even_array(a);
                    break;
                case 7:
                    ar.odd_array(a);
                    break;
            }
            System.out.println("Do you want to see main menu again press 1");
            z = sc.nextInt();
        }
        while(z==1);
    }
}
