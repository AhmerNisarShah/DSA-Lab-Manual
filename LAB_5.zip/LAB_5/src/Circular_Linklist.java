import java.util.Scanner;

public class Circular_Linklist {
    static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }
    Node head = null;
    Node tail = null;
    public void creation(){
        int data,n,m,p;
        Scanner sc = new Scanner(System.in);
        do{
            System.out.println("Enter data: ");
            data = sc.nextInt();
            Node new_node = new Node(data);
            if(head==null){
                head=new_node;
                tail=new_node;
                new_node.next=head;
            }
            else{
                System.out.println("Enter 1 to insert at the start , Enter 2 to insert at the end , Enter 3 to insert at the specific position");
                m = sc.nextInt();
                switch(m){
                    case 1 :
                        new_node.next=head;
                        head=new_node;
                        tail.next=new_node;
                        break;
                    case 2 :
                        tail.next=new_node;
                        tail=new_node;
                        new_node.next=head;
                        break;
                    case 3 :    // same as single linked list
                        System.out.println("Enter position of the node to be inserted: ");
                        p=sc.nextInt();
                        Node temp1=head;
                        for(int i=0;i<(p-1);i++){
                            temp1=temp1.next;
                        }
                        new_node.next=temp1.next;
                        temp1.next=new_node;
                        break;
                }
            }
            System.out.println("Do you want to enter more data, if yes press 1: ");
            n=sc.nextInt();
        }
        while(n==1);
    }
    public void delete(){
        int data,n,m,p;
        Scanner sc = new Scanner(System.in);
        do{
            if(head==null){
                System.out.println("Linked list is empty!");
            }
            else{
                System.out.println("Enter 1 to delete from the start , Enter 2 to delete from the end , Enter 3 to delete from the specific position");
                m=sc.nextInt();
                switch(m){
                    case 1 :
                        Node temp = head;
                        temp = temp.next;
                        head = temp;
                        tail.next = head;
                        break;
                    case 2 :
                        Node temp1 = head;
                        Node ptr = temp1.next;
                        while(ptr.next!=head){
                            temp1=ptr;
                            ptr=ptr.next;
                        }
                        temp1.next=head;
                        tail=temp1;
                        break;
                    case 3 :
                        System.out.println("Enter position of node to be deleted: ");
                        p=sc.nextInt();
                        Node temp2=head;
                        Node ptr1=temp2.next;
                        for(int i=0;i<(p-1);i++){
                            temp2=ptr1;
                            ptr1=ptr1.next;
                        }
                        temp2.next=ptr1.next;
                        break;
                }
            }
            System.out.println("Do you want to delete more data, if yes press 1!!");
            n=sc.nextInt();
        }
        while(n==1);

    }
    public void traverse(){
        Node temp=head;
        if(head==null){
            System.out.println("linked list not existed!");
        }
        else{
            do
            {
                System.out.print(temp.data+ " ");
                temp=temp.next;
            }
            while(temp!=head);
        }
    }

    public void reverse() {
        System.out.println("Reverse Linklist");
        Node current = head;
        Node prev = null;
        Node temp=null;

        do {
            temp = current.next;
            current.next = prev;
            prev = current;
            current = temp;
        } while (current != head);

        head = prev;
        tail = head;

        Node reversed = head;
        do {
            System.out.print(reversed.data + " ");
            reversed = reversed.next;
        } while (reversed != head);
    }

    public void middle() {
        Node s = head;
        Node f = head;

        do {
            s = s.next;
            f = f.next;
            if (f != null) {
                f = f.next;
            }
        }
        while (f != head && f != null && f.next != head);
        System.out.println("Middle Value: " + s.data);
    }
    public void min() {
        int min = head.data;
        Node temp = head.next;
        do {
            if (temp.data < min) {
                min = temp.data;
            }
            temp = temp.next;
        } while (temp != head);
        System.out.println("maximum value is: "+min);
    }

    public void max() {
        int max = head.data;
        Node temp = head.next;

        do {
            if (temp.data > max) {
                max = temp.data;
            }
            temp = temp.next;
        } while (temp != head);
        System.out.println("maximum value is: "+max);
    }

    public static void main(String[] args) {
        Circular_Linklist c1 = new Circular_Linklist();
        Scanner sc = new Scanner(System.in);
        int z;
        do {

            System.out.println("Select Operation\n1)Insert\n2)Delete\n3)Reverse\n4)Display\n5)Middle value\n6)Max value\n7)Min value");
            int ch = sc.nextInt();
            switch (ch) {
                case 1:
                    c1.creation();
                    break;
                case 2:
                    c1.delete();
                    break;
                case 3:
                    c1.reverse();
                    break;
                case 4:
                    c1.traverse();
                    break;
                case 5:
                    c1.middle();
                    break;
                case 6:
                    c1.max();
                    break;
                case 7:
                    c1.min();
                    break;
            }
            System.out.println("To go back to main menu press 1");
            z = sc.nextInt();
        }
        while (z == 1);
    }
}