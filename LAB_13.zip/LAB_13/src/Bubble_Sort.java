import java.util.Scanner;
public class Bubble_Sort {
    public void bubble_sort(){
        int size , i , j , temp;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of elements: ");
        size = sc.nextInt();
        int[] array = new int[size];

        for(i=0;i<size;i++){
            System.out.println("Enter the element "+i);
            array[i]=sc.nextInt();
        }

        for(i=0;i<size;i++){
            for(j=0;j<(size-i-1);j++){
                if(array[j]>array[j+1]){
                    temp=array[j];
                    array[j]=array[j+1];
                    array[j+1]=temp;
                }
            }
        }
        System.out.println("Sorted elements are listed below");
        for(i=0;i<size;i++){
            System.out.println(array[i]);
        }
    }

    public static void main(String[] args) {
        Bubble_Sort b_s = new Bubble_Sort();
        b_s.bubble_sort();
    }
}
