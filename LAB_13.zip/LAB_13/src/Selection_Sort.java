import java.util.Scanner;
public class Selection_Sort{
    public void selection_sort() {
        int size, i, j, temp, location;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of elements: ");
        size = sc.nextInt();
        int[] array = new int[size];

        for (i = 0; i < size; i++) {
            System.out.println("Enter the element " + i);
            array[i] = sc.nextInt();
        }

        for (i = 0; i < (size - 1); i++) {
            location = i;
            for (j = (i + 1); j < size; j++) {
                if (array[j] < array[location]) {
                    location = j;
                }
            }
            temp = array[i];
            array[i] = array[location];
            array[location] = temp;
        }
        System.out.println("Sorted elements are listed below");
        for(i=0;i<size;i++){
            System.out.println(array[i]);
        }
    }

    public static void main(String[] args) {
        Selection_Sort s_s = new Selection_Sort();
        s_s.selection_sort();
    }
}