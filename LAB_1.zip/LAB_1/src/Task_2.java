public class Task_2 {
    public void element(int[] num){
        System.out.println(num[0]);
        System.out.println(num[1]);
        System.out.println(num[2]);
        System.out.println(num[3]);
    }
    public static void main(String[] args) {
        Task_2 t_2 = new Task_2();
        int[] array = {101,102,103,104};
        t_2.element(array);
    }
}
