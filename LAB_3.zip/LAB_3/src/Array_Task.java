import java.util.Scanner;

public class Array_Task {
    private int[] array;
    private int size;
    public Array_Task(int i_size) {
        array = new int[i_size];
        size = 0;
    }
    public void insert(int value) {
        if (size < array.length) {
            array[size] = value;
            size++;
        } else {
            int[] array2 = new int[(array.length * 2)];
            for (int i = 0; i < array.length; i++) {
                array2[i] = array[i];
            }
            array2[array.length] = value;
            array = array2;
            size++;
        }
    }
    public void remove(int index) {
        if (index < 0 || index >= array.length) {
            throw new ArrayIndexOutOfBoundsException();
        }
        else {
            for (int i = index; i < array.length; i++) {
                if (i == (array.length - 1)){
                    array[(array.length - 1)] = 0;
                    continue;
                }
                else {
                    array[i] = array[i + 1];
                }}
            size--;
        }
    }
    public void Searchbyindex(int index){
        if (index < 0 || index >= array.length) {
            throw new ArrayIndexOutOfBoundsException();
        }
        System.out.println("Value At Index Number "+index+" is "+array[index]);
    }
    public void Searchbyvalue(int value){
        for (int i=0; i< array.length;i++){
            if(array[i] == value){
                System.out.println("At Index Number: "+i);
            }
        }
    }
    public void sum(){
        int sum=0;
        for (int i=0;i< array.length;i++){
            sum+=array[i];
        }
        System.out.println("Sum of array:"+sum);
    }
    public void prod(){
        int pro=1;
        for (int i=0;i< array.length;i++){
            pro*=array[i];
        }
        System.out.println("Product of array:"+pro);
    }
    public void max(){
        int max = array[0];
        for (int i=0;i< array.length;i++){
            if(max<=array[i])
            {
                max=array[i];
            }
        }
        System.out.println("Maximum Value is: "+max);
    }
    public void min(){
        int min = array[0];
        for (int i=0;i< array.length;i++){
            if(min>=array[i])
            {
                min=array[i];
            }
        }
        System.out.println("Minimum Value is: "+min);
    }
    public void average(){
        double total=0;
        for (int i=0;i< array.length;i++){
            total+=array[i];
        }
        double average = (total / size);
        System.out.println("Average Value is: "+ average);
    }
    public void even(){
        System.out.println("Even Numbers Are:");
        for (int i=0;i< array.length;i++){
            if(array[i]%2==0){
                System.out.println(array[i]);
            }
        }
    }
    public void odd(){
        System.out.println("Odd Numbers Are:");
        for (int i=0;i< array.length;i++){
            if(array[i]%2!=0){
                System.out.println(array[i]);
            }
        }
    }
    public void reverse(){
        System.out.println("Reverse Array");
        for (int i=(size-1); i>=0;i--){
            System.out.println(array[i]);
        }
    }
    public void replace(int index, int value){
        if (index < 0 || index >= array.length) {
            throw new ArrayIndexOutOfBoundsException();
        }
        array[index]=value;
    }
    public void common(int[] arr1,int[] arr2)
    {
        for (int i=0;i<arr2.length;i++)
        {
            for (int j=0;j<arr1.length;j++){
                if(arr1[j] == arr2[i])
                {
                    System.out.println("Array 1 index no."+j+" have same value as Array 2 index no."+i+" Value:"+arr1[j]);
                }
            }
        }
    }
    public void prime(){
        for (int i=0;i<size;i++){
            boolean prime=true;
            if(array[i] > 1 && array[i] <= 3)
            {
                System.out.println(array[i]+" is a prime number");
            }
            else {
                for (int j = (array[i]-1); j >= 2; j--) {
                    if (array[i] % j == 0) {
                        prime = false;
                    }
                }
                if(prime == true){
                    System.out.println(array[i]+" is a prime number");
                }
            }
        }
    }
    public void distinct(){
        for(int i=0;i<size;i++){
            boolean repeat = false;
            for(int j=0;j<size;j++){
                if(i == j){
                    continue;
                }
                else{
                    if (array[i] == array[j]) {
                        repeat=true;
                    }
                }
            }
            if (repeat == false)
            {
                System.out.println(array[i]+" is a distinct number");
            }
        }
    }
    public void Print() {
        System.out.println("Array");
        for (int i = 0; i < size; i++) {
            System.out.println(array[i]);
        }
    }

    public int getSize() {
        return size;
    }


    public static void main(String[] args)
    {
        int j=0 , z=0;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Array Size:");
        int n = sc.nextInt();
        Array_Task array = new Array_Task(n);
        do{
            System.out.println("Select Operation\n1)Insert Value\n2)Remove\n3)Search By Value\n4)Search By Index\n5)Maximum Value\n6)Minimum Value\n7)Common Value\n8)Product\n9)Average\n10)Reverse\n11)Distinct\n12)Replace Value\n13)Even Numbers\n14)Odd Numbers\n15)Prime Number\n16)Display\n17)End:");
            int ch = sc.nextInt();
            switch (ch){
                case 1:
                    System.out.println("Enter Value:");
                    int value = sc.nextInt();
                    array.insert(value);
                    break;
                case 2:
                    System.out.println("Enter Index:");
                    int i = sc.nextInt();
                    array.remove(i);
                    break;
                case 3:
                    System.out.println("Enter Value:");
                    int val = sc.nextInt();
                    array.Searchbyvalue(val);
                    break;
                case 4:
                    System.out.println("Enter Index:");
                    int in = sc.nextInt();
                    array.Searchbyindex(in);
                    break;
                case 5:
                    array.max();
                    break;
                case 6:
                    array.min();
                    break;
                case 7:
                    System.out.println("Enter Length of Array 1:");
                    int a_1_len=sc.nextInt();
                    int[] arr1 = new int[a_1_len];
                    for (int b =0 ; b<a_1_len ; b++){
                        System.out.println("Enter Value on index"+ b+" in Array 1:");
                        arr1[b]=sc.nextInt();
                    }
                    System.out.println("Enter Length of Array 2:");
                    int a_2_len=sc.nextInt();
                    int[] arr2 = new int[a_2_len];
                    for (int c =0 ; c<a_2_len ; c++){
                        System.out.println("Enter Value on index"+ c+" in Array 2:");
                        arr2[c]=sc.nextInt();
                    }
                    array.common(arr1,arr2);
                    break;
                case 8:
                    array.prod();
                    break;
                case 9:
                    array.average();
                    break;
                case 10:
                    array.reverse();
                    break;
                case 11:
                    array.distinct();
                    break;
                case 12:
                    System.out.println("Enter Index:");
                    int ind = sc.nextInt();
                    System.out.println("Enter Value:");
                    int v = sc.nextInt();
                    array.replace(ind,v);
                    break;
                case 13:
                    array.even();
                    break;
                case 14:
                    array.odd();
                    break;
                case 15:
                    array.prime();
                    break;
                case 16:
                    array.Print();
                case 17:
                    j=1;
                    break;
            }
            System.out.println("If you want to see main menu press 1");
            z = sc.nextInt();
        }
        while(z==1);
    }
}